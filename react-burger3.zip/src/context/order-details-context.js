import { createContext } from "react";

const OrderDetailsContext = createContext([]);
export default OrderDetailsContext;
