import { createContext } from "react";

const BurgerIngredientsContext = createContext([]);
export default BurgerIngredientsContext;
