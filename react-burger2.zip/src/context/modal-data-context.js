import { createContext } from "react";

const ModalDataContext = createContext([]);
export default ModalDataContext;
